# CapsNet
> A pytorch implementation of capsule network.
>
> Reference: https://arxiv.org/abs/1710.09829
